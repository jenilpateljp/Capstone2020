<?php
    $host = "localhost";
    $user = "root";                     
    $pass = "";                         
    $db = "db_movies";                  
     $con = mysqli_connect($host, $user, $pass, $db)or die(mysql_error());
?>