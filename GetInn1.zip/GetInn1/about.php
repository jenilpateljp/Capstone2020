<?php include('header.php');
	$qry2=mysqli_query($con,"select * from tbl_movie where movie_id='".$_GET['id']."'");
	$movie=mysqli_fetch_array($qry2);
	?>

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Movies</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li><?php echo $movie['movie_name']; ?></li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

      
    <section class="inner-page mt-4">
      <div class="container">
          <div class="row">
              <div class="col-lg-5 box">
                  <img src="<?php echo $movie['image']; ?>" alt=""/>
              </div>
              
              <div class="col-lg-7 box">
                <h3><?php echo $movie['movie_name']; ?></h3>
                <div class="desc span_3_of_2">
                    <p class="p-link" style="font-size:15px">Cast : <?php echo $movie['cast']; ?></p>
                    <p class="p-link" style="font-size:15px">Release Date : <?php echo date('d-M-Y',strtotime($movie['release_date'])); ?></p>
                    <p style="font-size:15px"><?php echo $movie['desc']; ?></p>
                    <a href="<?php echo $movie['video_url']; ?>" target="_blank" class="watch_but">Watch Trailer</a>
                </div>
              </div>
              
        </div>
      </div>
    </section>

<?php include('footer.php');?>