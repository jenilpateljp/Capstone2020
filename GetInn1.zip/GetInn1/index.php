<?php include('header.php');?>

  <main id="main">

    <section id="clients">
      <div>

        <div class="owl-carousel clients-carousel">
          <img src="assets/img/slide-1.jpg" alt="">
          <img src="assets/img/slide-2.jpg" alt="">
          <img src="assets/img/slide-3.jpg" alt="">
          <img src="assets/img/slide-4.jpg" alt="">
          <img src="assets/img/slide-5.jpg" alt="">
        </div>

      </div>
    </section>
      
  </main>
    
<?php include('footer.php');?>