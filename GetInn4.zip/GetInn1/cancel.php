<?php include('header.php');?>

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Movies</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>Movies</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="inner-page mt-4">
      <div class="container">
          <div class="row">
              <h5>Your PayPal transaction has been canceled.</h5>
      </div>
      </div>
    </section>

  </main><!-- End #main -->

  <?php include('footer.php');?>