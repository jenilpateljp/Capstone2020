<?php
    $host = "localhost";
    $user = "vishax9f_getinn";                     
    $pass = "admin@getinn";                         
    $db = "vishax9f_getinn";                  
     
    $con = mysqli_connect($host, $user, $pass, $db);

 if($con == false) {
     die("Error: " . mysql_error());
 }
?>