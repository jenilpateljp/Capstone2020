<?php include('header.php');?>

  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Movies</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>Movies</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="inner-page mt-4">
      <div class="container">
          <div class="row">
              
              
            <?php
                $today=date("Y-m-d");
                $qry2=mysqli_query($con,"select * from  tbl_movie ");

                while($m=mysqli_fetch_array($qry2)){ ?>

                    <div class="col-lg-3 box">
                        <div class="movie-box">
                                <a href="about.php?id=<?php echo $m['movie_id'];?>"><img src="<?php echo $m['image'];?>" alt="movies" /></a>
                                <h4 class="movie-title"><a href="about.php?id=<?php echo $m['movie_id'];?>"><?php echo $m['movie_name'];?></a></h4>
                                <p>Cast: <Span class="color2"><?php echo $m['cast'];?></span></p>
                            <a href="about.php?id=<?php echo $m['movie_id'];?>">Book Now</a>
                        </div>
                    </div>

                <?php } ?>
      </div>
      </div>
    </section>

  </main><!-- End #main -->

  <?php include('footer.php');?>