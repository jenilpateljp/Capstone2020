<?php include('header.php');?>

  <main id="main">
      
    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Food</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>Food</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->
    <section class="inner-page mt-4">
      <div class="container">
          <div class="row">
              <div class="col-md-4">
                  <div class="food-title">
                      <h3>Popcorn</h3>
                  </div>
                  <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui bland itiis praesentium voluptatum deleniti atque corrupti.</p>
                  <div class="food-img">
                    <img src="assets/img/food-1.jpg">
                  </div>
              </div>
            <div class="col-md-4">
                  <div class="food-title">
                      <h3>Coca-cola</h3>
                  </div>
                  <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui bland itiis praesentium voluptatum deleniti atque corrupti.</p>
                  <div class="food-img">
                    <img src="assets/img/food-2.jpg">
                  </div>
              </div>
              <div class="col-md-4">
                  <div class="food-title">
                      <h3>Hot Dog</h3>
                  </div>
                  <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui bland itiis praesentium voluptatum deleniti atque corrupti.</p>
                  <div class="food-img">
                    <img src="assets/img/food-3.jpg">
                  </div>
              </div>
          </div>
      </div>
    </section>
      
  </main>
    
<?php include('footer.php');?>